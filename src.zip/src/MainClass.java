/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class MainClass 
{
    //change your mysql database connection here
    public String StrUrl="jdbc:mysql://localhost/p2p_library";
    public String StrUid="root";
    public String StrPwd= "";
    
    public static String StrUser;
            

}
